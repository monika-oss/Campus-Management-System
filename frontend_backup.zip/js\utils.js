const utils = {
  showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.style.position = 'fixed';
      container.style.top = '20px';
      container.style.right = '20px';
      container.style.zIndex = '9999';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    if (type === 'error') icon = '❌';
    if (type === 'warning') icon = '⚠️';

    toast.innerHTML = `
      <div class="toast-icon">${icon}</div>
      <div class="toast-message">${message}</div>
    `;

    container.appendChild(toast);

    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 10);

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  },

  showModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
      modal.classList.remove('hidden');
      modal.classList.add('active');
    }
  },

  hideModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('active');
    }
  },

  formatDate(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB'); // DD/MM/YYYY
  },

  formatDateTime(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const datePart = date.toLocaleDateString('en-GB');
    const timePart = date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    return `${datePart} ${timePart}`;
  },

  debounce(func, delay) {
    let timeoutId;
    return function (...args) {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        func.apply(null, args);
      }, delay);
    };
  },

  exportCSV(data, filename) {
    if (!data || !data.length) return;
    
    const keys = Object.keys(data[0]);
    const csvContent = [
      keys.join(','),
      ...data.map(row => keys.map(k => `"${row[k] || ''}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  },

  gradeFromMarks(marks) {
    if (marks >= 90) return { grade: 'A+', class: 'badge-success' };
    if (marks >= 80) return { grade: 'A', class: 'badge-success' };
    if (marks >= 70) return { grade: 'B+', class: 'badge-info' };
    if (marks >= 60) return { grade: 'B', class: 'badge-info' };
    if (marks >= 50) return { grade: 'C', class: 'badge-warning' };
    if (marks >= 40) return { grade: 'D', class: 'badge-warning' };
    return { grade: 'F', class: 'badge-danger' };
  }
};

// Global event listeners for modals
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('active');
    e.target.classList.add('hidden');
  }
  if (e.target.classList.contains('modal-close') || e.target.closest('.modal-close')) {
    const modal = e.target.closest('.modal-overlay');
    if (modal) {
      modal.classList.remove('active');
      modal.classList.add('hidden');
    }
  }
});


document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.sidebar-item-link').forEach(link => {
        link.addEventListener('click', function() {
            document.querySelectorAll('.sidebar-item-link').forEach(l => {
                l.classList.remove('bg-blue-600', 'text-white', 'shadow-md', 'shadow-blue-600/20');
                l.classList.add('text-slate-200');
            });
            this.classList.remove('text-slate-200', 'hover:bg-slate-800');
            this.classList.add('bg-blue-600', 'text-white', 'shadow-md', 'shadow-blue-600/20');
        });
    });
});

// Global Notification Drawer
const NotificationDrawer = {
  isOpen: false,
  notifications: [],
  activeTab: 'unread',
  
  init() {
    if (document.getElementById('notification-drawer')) return;
    
    const overlay = document.createElement('div');
    overlay.id = 'nd-overlay';
    overlay.className = 'fixed inset-0 bg-black bg-opacity-40 backdrop-blur-sm z-40 hidden transition-opacity opacity-0';
    overlay.onclick = () => this.close();
    
    const drawer = document.createElement('div');
    drawer.id = 'notification-drawer';
    drawer.className = 'fixed top-0 right-0 h-full w-full max-w-sm bg-white shadow-2xl z-50 transform translate-x-full transition-transform duration-300 flex flex-col font-sans';
    
    drawer.innerHTML = `
      <div class="px-5 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
        <h2 class="text-lg font-bold text-slate-800 flex items-center gap-2">
          <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
          Notifications
        </h2>
        <button onclick="NotificationDrawer.close()" class="text-slate-400 hover:text-slate-600 bg-white hover:bg-slate-100 rounded-full p-1.5 transition-colors focus:outline-none">
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>
      </div>
      
      <div class="px-5 py-2 border-b border-slate-100 flex gap-4 text-sm font-semibold">
        <button id="nd-tab-unread" onclick="NotificationDrawer.setTab('unread')" class="pb-2 border-b-2 border-blue-600 text-blue-600 transition-colors">Unread (<span id="nd-unread-count">0</span>)</button>
        <button id="nd-tab-read" onclick="NotificationDrawer.setTab('read')" class="pb-2 border-b-2 border-transparent text-slate-500 hover:text-slate-700 transition-colors">Read</button>
      </div>
      
      <div class="px-5 py-3 flex justify-between items-center bg-white border-b border-slate-50 shadow-sm text-xs">
        <button onclick="NotificationDrawer.markAllRead()" class="text-blue-600 hover:text-blue-700 font-semibold transition-colors flex items-center gap-1">
           <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg> Mark all read
        </button>
        <button onclick="NotificationDrawer.deleteAll()" class="text-red-500 hover:text-red-600 font-semibold transition-colors flex items-center gap-1">
           <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg> Clear all
        </button>
      </div>
      
      <div id="nd-content" class="flex-1 overflow-y-auto bg-slate-50/50 p-3 space-y-2">
        <div class="text-center py-10 text-slate-400 text-sm">Loading...</div>
      </div>
    `;
    
    document.body.appendChild(overlay);
    document.body.appendChild(drawer);
  },
  
  open() {
    this.init();
    const overlay = document.getElementById('nd-overlay');
    const drawer = document.getElementById('notification-drawer');
    overlay.classList.remove('hidden');
    setTimeout(() => {
      overlay.classList.remove('opacity-0');
      drawer.classList.remove('translate-x-full');
    }, 10);
    this.isOpen = true;
    this.fetchNotifications();
  },
  
  close() {
    const overlay = document.getElementById('nd-overlay');
    const drawer = document.getElementById('notification-drawer');
    if(!drawer) return;
    overlay.classList.add('opacity-0');
    drawer.classList.add('translate-x-full');
    setTimeout(() => overlay.classList.add('hidden'), 300);
    this.isOpen = false;
  },
  
  toggle() {
    this.isOpen ? this.close() : this.open();
  },
  
  setTab(tab) {
    this.activeTab = tab;
    document.getElementById('nd-tab-unread').className = tab === 'unread' ? 'pb-2 border-b-2 border-blue-600 text-blue-600 transition-colors' : 'pb-2 border-b-2 border-transparent text-slate-500 hover:text-slate-700 transition-colors';
    document.getElementById('nd-tab-read').className = tab === 'read' ? 'pb-2 border-b-2 border-blue-600 text-blue-600 transition-colors' : 'pb-2 border-b-2 border-transparent text-slate-500 hover:text-slate-700 transition-colors';
    this.render();
  },
  
  async fetchNotifications() {
    try {
      const data = await api.get('/notifications/');
      this.notifications = Array.isArray(data) ? data : (data.results || []);
      this.updateCounters();
      this.render();
    } catch (e) {
      document.getElementById('nd-content').innerHTML = '<div class="text-center py-10 text-red-400 text-sm">Failed to load</div>';
    }
  },
  
  updateCounters() {
    const unreadCount = this.notifications.filter(n => !n.is_read).length;
    document.getElementById('nd-unread-count').textContent = unreadCount;
    NotificationService.updateBadge(unreadCount);
  },
  
  render() {
    const content = document.getElementById('nd-content');
    const filtered = this.notifications.filter(n => this.activeTab === 'unread' ? !n.is_read : n.is_read);
    
    if (filtered.length === 0) {
      content.innerHTML = `
        <div class="flex flex-col items-center justify-center py-12 text-slate-400">
          <svg class="w-12 h-12 mb-3 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path></svg>
          <span class="text-sm font-medium">No ${this.activeTab} notifications</span>
        </div>
      `;
      return;
    }
    
    content.innerHTML = filtered.map(n => {
      let icon = '<div class="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div>';
      if(n.notification_type === 'success') icon = '<div class="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center flex-shrink-0"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg></div>';
      if(n.notification_type === 'warning') icon = '<div class="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center flex-shrink-0"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg></div>';
      if(n.notification_type === 'error') icon = '<div class="w-8 h-8 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center flex-shrink-0"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></div>';
      
      const timeStr = utils.formatDateTime(n.created_at);
      
      return `
        <div class="bg-white p-3 rounded-lg shadow-sm border border-slate-100 relative group hover:border-blue-200 transition-colors">
          <div class="flex gap-3">
            ${icon}
            <div class="flex-1 min-w-0">
              <h4 class="text-sm font-bold text-slate-800 truncate">${n.title}</h4>
              <p class="text-xs text-slate-600 mt-1 line-clamp-2">${n.description}</p>
              <div class="text-[10px] text-slate-400 mt-2 font-medium">${timeStr}</div>
            </div>
          </div>
          
          <div class="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col gap-1">
            ${!n.is_read ? `<button onclick="NotificationDrawer.markRead(${n.notification_id})" class="p-1.5 bg-slate-50 hover:bg-blue-50 text-blue-600 rounded-md transition-colors" title="Mark as read"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg></button>` : ''}
            <button onclick="NotificationDrawer.deleteSingle(${n.notification_id})" class="p-1.5 bg-slate-50 hover:bg-red-50 text-red-500 rounded-md transition-colors" title="Delete"><svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
          </div>
        </div>
      `;
    }).join('');
  },
  
  async markRead(id) {
    try {
      await api.post(`/notifications/${id}/read/`, {});
      const notif = this.notifications.find(n => n.notification_id === id);
      if (notif) notif.is_read = true;
      this.updateCounters();
      this.render();
    } catch(e) {
      console.error(e);
    }
  },
  
  async deleteSingle(id) {
    try {
      await api.post(`/notifications/${id}/hide/`, {});
      this.notifications = this.notifications.filter(n => n.notification_id !== id);
      this.updateCounters();
      this.render();
    } catch(e) {
      console.error(e);
    }
  },
  
  async markAllRead() {
    try {
      await api.post('/notifications/mark_all_read/', {});
      this.notifications.forEach(n => n.is_read = true);
      this.updateCounters();
      this.render();
      utils.showToast('All marked as read', 'success');
    } catch(e) {
      console.error(e);
    }
  },
  
  async deleteAll() {
    if(!confirm("Are you sure you want to clear all notifications?")) return;
    try {
      await api.post('/notifications/delete_all/', {});
      this.notifications = [];
      this.updateCounters();
      this.render();
      utils.showToast('All notifications cleared', 'success');
    } catch(e) {
      console.error(e);
    }
  }
};

// Global Notification Service for Live Notifications
const NotificationService = {
  interval: null,
  
  startPolling() {
    if (this.interval) return;
    this.poll(); // Initial poll
    // Removed setInterval as per user request to stop API spam
  },
  
  stopPolling() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
  },
  
  poll() {
    if (!auth.checkAuth()) return;
    
    api.get('/notifications/unread/')
      .then(data => {
        this.updateBadge(data.count);
        this.showNewToasts(data.notifications);
        if (NotificationDrawer.isOpen) {
          NotificationDrawer.fetchNotifications();
        }
      })
      .catch(err => console.error('Notification poll failed', err));
  },
  
  updateBadge(count) {
    const badges = document.querySelectorAll('.notification-badge');
    badges.forEach(badge => {
      if (count > 0) {
        badge.textContent = count > 9 ? '9+' : count;
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    });
  },
  
  showNewToasts(notifications) {
    if (!notifications || !notifications.length) return;
    
    let toastedStr = localStorage.getItem('toasted_notifications') || '[]';
    let toasted = JSON.parse(toastedStr);
    let hasNew = false;
    
    notifications.forEach(notif => {
      if (!toasted.includes(notif.notification_id)) {
        utils.showToast(notif.title + ': ' + notif.description, notif.notification_type || 'info');
        toasted.push(notif.notification_id);
        hasNew = true;
      }
    });
    
    if (hasNew) {
      if (toasted.length > 50) toasted = toasted.slice(toasted.length - 50);
      localStorage.setItem('toasted_notifications', JSON.stringify(toasted));
    }
  }
};

// Start polling on load if authenticated
document.addEventListener('DOMContentLoaded', () => {
    if (localStorage.getItem('access_token')) {
        NotificationService.startPolling();
    }
});


utils.exportTableToCSV = function(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    let csv = [];
    for (let i = 0; i < table.rows.length; i++) {
        let row = [], cols = table.rows[i].querySelectorAll('td, th');
        
        let limit = cols.length;
        if (i === 0 && cols[limit - 1] && cols[limit - 1].innerText.trim().toLowerCase() === 'actions') {
            limit = cols.length - 1;
        } else if (i > 0 && table.rows[0].querySelectorAll('th').length > 0) {
            const headerCols = table.rows[0].querySelectorAll('th');
            if (headerCols[headerCols.length - 1].innerText.trim().toLowerCase() === 'actions') {
                limit = cols.length - 1;
            }
        }
        
        for (let j = 0; j < limit; j++) {
            let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/"/g, '""').trim();
            row.push('"' + data + '"');
        }
        csv.push(row.join(','));
    }
    const csvFile = new Blob([csv.join('\n')], {type: 'text/csv'});
    const downloadLink = document.createElement('a');
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
};
